
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fastapi.testclient import TestClient
from src.api import app

client = TestClient(app)

def valid_job():
    return {
        "filament_material":"PLA",
        "nozzle_temperature_c":205,
        "bed_temperature_c":60,
        "printing_speed_mm_s":50,
        "ambient_temperature_c":24,
        "cooling_fan_speed_pct":65,
        "component_base_area_mm2":1200,
        "layer_height_mm":0.20
    }

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"

def test_prediction():
    response = client.post("/predict", json=valid_job())
    assert response.status_code == 200
    body = response.json()
    assert body["prediction"] in ["Warping Risk", "Print Conditions Acceptable"]
    assert 0 <= body["warping_probability"] <= 1

def test_invalid_temperature_rejected():
    job = valid_job()
    job["bed_temperature_c"] = 500
    response = client.post("/predict", json=job)
    assert response.status_code == 422

def test_invalid_material_rejected():
    job = valid_job()
    job["filament_material"] = "NYLON"
    response = client.post("/predict", json=job)
    assert response.status_code == 422
