
from pathlib import Path
import joblib
import pandas as pd
import numpy as np
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

BASE = Path(__file__).resolve().parents[1]
bundle = joblib.load(BASE / "artifacts" / "warping_model.joblib")
model = bundle["model"]
app = FastAPI(title="FDM Warping Defect Prediction API", version="1.0")

class PrintJob(BaseModel):
    filament_material: str
    nozzle_temperature_c: float = Field(ge=170, le=300)
    bed_temperature_c: float = Field(ge=20, le=130)
    printing_speed_mm_s: float = Field(ge=5, le=200)
    ambient_temperature_c: float = Field(ge=-5, le=60)
    cooling_fan_speed_pct: float = Field(ge=0, le=100)
    component_base_area_mm2: float = Field(ge=10, le=20000)
    layer_height_mm: float = Field(ge=0.05, le=0.5)

def engineer(df):
    df = df.copy()
    df["nozzle_bed_temperature_difference"] = df["nozzle_temperature_c"] - df["bed_temperature_c"]
    factor = df["filament_material"].map({"PLA":0.8,"ABS":1.35,"PETG":1.0})
    df["cooling_stress_index"] = (
        (df["nozzle_bed_temperature_difference"].clip(lower=0)/100)
        * (1 + df["cooling_fan_speed_pct"]/100)
        * (1 + np.maximum(0,25-df["ambient_temperature_c"])/25)
        * factor
    )
    return df[[
        "nozzle_temperature_c","bed_temperature_c","printing_speed_mm_s",
        "ambient_temperature_c","cooling_fan_speed_pct","component_base_area_mm2",
        "layer_height_mm","nozzle_bed_temperature_difference","cooling_stress_index",
        "filament_material"
    ]]

@app.get("/health")
def health():
    return {"status":"healthy", "model":bundle["model_name"]}

@app.post("/predict")
def predict(job: PrintJob):
    if job.filament_material not in ["PLA","ABS","PETG"]:
        raise HTTPException(status_code=422, detail="filament_material must be PLA, ABS or PETG")
    raw = pd.DataFrame([job.model_dump()])
    x = engineer(raw)
    prob = float(model.predict_proba(x)[0,1])
    label = "Warping Risk" if int(model.predict(x)[0]) == 1 else "Print Conditions Acceptable"
    return {"prediction":label, "warping_probability":round(prob,4)}
